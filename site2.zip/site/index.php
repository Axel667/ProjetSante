<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
    <link rel="shortcut icon" type="image/png" href="https://animaproject.s3.amazonaws.com/home/favicon.png" />
    <link rel="stylesheet" type="text/css" href="site.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <?php include("baseD.php")?>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="index.php"><h2>SantÉconomie</h2></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <ul class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="carte.html">Carte</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="compare.html">Comparer</a>
              </li>
            </ul>
            <ul class="navbar-nav ms-auto"></ul>
             <form class="d-flex" method="GET" action="recherche.php">
                <input class="form-control me-2" name="s" type="search" placeholder="Search">
                <input type="submit" name="envoyer">
              </form>
              <?php
              
              session_start();

              if (!isset($_SESSION['client'])){
              echo '<li class="nav-item">
                <a class="nav-link" href="sign-in.php"><img src="img/user@2x.png" style="height: 30px; width: 30px;"></a>
              </li>';
              }
              else{
                echo '<li class="nav-item">
                <a class="nav-link active" href="profil.php"><img src="img/user@2x.png" style="height: 30px; width: 30px;"></a></li>';
                
                echo '<li class="nav-item"><a class="nav-link active" href="deconnexion.php">Log out</a></li>';
                
              }
              ?>
            
              
            </ul> 
            </div>
            </div>
            </nav>
            <?php
            if (!isset($_SESSION['client'])){
              echo "<h3><a href='sign-in.php'>Sign in</a><h3>";
            }
            else{
            echo "<p>Bonjour ".$_SESSION['client']['genre']." ".$_SESSION['client']['Nom']." ".$_SESSION['client']['Prenom']."</p>";
            }
            ?>
  <div class="btn-index">
        <div>
          <button type="button" class="btn btn-light btn-lg"><img class="tb" src="img/world@2x.png"><a class="link-btn" href="carte.html">Découvrez notre carte</a></button>
      </div>
        <div>
        <button type="button" class="btn btn-light btn-lg" ><img class="tb" src="img/compare@2x.png"><a class="link-btn" href="compare.html">Comparez les pays</button>
      </div>
        <div>
        <button type="button" class="btn btn-light btn-lg"><img class="tb" src="img/user-1@2x.png"><a class="link-btn" href="#">Publiez votre article</button>
      </div>
  </div>



</body>
</html>